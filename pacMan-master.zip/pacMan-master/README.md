# PacMan Exercise
<img src='PacMan1.png'>

In this exercise you need to detect when PacMan touches either the left or right side of the WebPage and reverse its direction and also flip the image to face the in the direction moved. eg use different images. 

You should also use the JavaScript function setTimeout to automate the movement.
